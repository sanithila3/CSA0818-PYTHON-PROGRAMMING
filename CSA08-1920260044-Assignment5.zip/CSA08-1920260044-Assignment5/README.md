# CSA08 - Assignment 5 (CO5)
Student: Nithila S A | Register No: 1920260044

## Run
    python TaskB1/cleaning.py
    python TaskB2/sqlite_demo.py
    python TaskB4/sentiment.py

Python version: <add yours>
Libraries: see requirements.txt (these three scripts use only the standard library)
