# CSA0818 - Python Programming, Assignment 2

- **Name:** Nithila S A
- **Register Number:** 1920260044
- **Python version:** 3.10+ (tested on 3.12; Task01 uses `match`, needs 3.10+)
- **Libraries:** standard library only (see requirements.txt)

## Run commands
```
python Task01/subsidy.py     # Q1 decisions and boundaries
python Task02/otp.py         # Q2 attempt-counting loops
python Task03/vehicle.py     # Q3 registration validator
python Task04/builder.py     # Q4 += vs join benchmark
python Task05/functions.py   # Q5 functions, defaults, scope
python Task06/recursion.py   # Q6 recursion, memoisation, iteration
python Task07/redesign.py    # Q7 redesign and validation
```

## Results (fill in after running on your own computer)
| Task | Short result |
|------|--------------|
| 01 | One decision per household; separate ifs give 2 labels for (80, ration card) |
| 02 | Blank entries not counted; lock after 3 (5 with correct security answer) |
| 03 | 3 valid, 3 invalid registrations as predicted |
| 04 | join faster than += ; outputs identical (paste your timings) |
| 05 | Mutable default shared; None-sentinel fixes it |
| 06 | naive 242785 calls vs memo 26 at n=25; iterative best for n=1000 |
| 07 | join redesign: same output, lower mean time (paste your timings) |
