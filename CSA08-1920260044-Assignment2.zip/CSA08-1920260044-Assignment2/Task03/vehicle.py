"""Q3 - Vehicle registration number validator."""
import re

def normalise(text):
    return "".join(ch for ch in text if ch.isalnum()).upper()

def is_valid(reg):
    """Slicing version: SS DD [A]{1,2} NNNN"""
    if not 9 <= len(reg) <= 10:
        return False
    state, district = reg[:2], reg[2:4]
    series, number = reg[4:-4], reg[-4:]
    return (state.isalpha() and district.isdigit()
            and 1 <= len(series) <= 2 and series.isalpha()
            and number.isdigit())

PATTERN = re.compile(r"[A-Z]{2}\d{2}[A-Z]{1,2}\d{4}")

def is_valid_regex(reg):
    return PATTERN.fullmatch(reg) is not None

def format_registration(reg):
    return f"{reg[:2]} {reg[2:4]} {reg[4:-4]} {reg[-4:]}"

if __name__ == "__main__":
    inputs = ["tn 09 ab 1234", "KA-01-M-0007", "mh 12 xy 4567",
              "TN9AB1234", "TN 22 1234 AB", "T 09 AB 1234"]
    for raw in inputs:
        n = normalise(raw)
        ok = is_valid(n)
        assert ok == is_valid_regex(n)
        shown = format_registration(n) if ok else "-"
        print(f"{raw!r:<18} {n:<12} {'Valid' if ok else 'Invalid':<8} {shown}")
