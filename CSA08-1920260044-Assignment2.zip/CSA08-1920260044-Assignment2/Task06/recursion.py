"""Q6 - Recursion and its limits (climbing stairs, 1 or 2 steps)."""
import sys
from functools import lru_cache

calls = 0

def ways_naive(n):
    global calls
    calls += 1
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)

memo_calls = 0

@lru_cache(maxsize=None)
def ways_memo(n):
    global memo_calls
    memo_calls += 1                      # counts only real computations
    if n <= 1:
        return 1
    return ways_memo(n - 1) + ways_memo(n - 2)

def ways_iter(n):
    prev, cur = 1, 1
    for _ in range(n - 1):
        prev, cur = cur, prev + cur
    return cur

if __name__ == "__main__":
    print("n  ways")
    for n in range(1, 7):
        print(f"{n}  {ways_naive(n)}")

    for n in (10, 20, 25):
        calls = 0
        r = ways_naive(n)
        ways_memo.cache_clear(); memo_calls = 0
        assert ways_memo(n) == r == ways_iter(n)
        print(f"n={n}: naive {r} calls = {calls}   memo calls = {memo_calls}")

    print("\nRecursion limit:", sys.getrecursionlimit())
    try:
        ways_memo.cache_clear()
        ways_memo(1000)
        print("memo(1000) worked")
    except RecursionError:
        print("memo(1000) -> RecursionError (memoisation does not reduce depth)")
    print("iterative(1000) has", len(str(ways_iter(1000))), "digits - no depth problem")
