"""Q5 - Functions, parameters and scope."""

def add_item_buggy(item, order=[]):          # BUG: default list created once
    order.append(item)
    return order

def add_item(item, order=None):              # FIX: None sentinel
    if order is None:
        order = []
    order.append(item)
    return order

def bill(price, qty=1, *, gst_rate=0.18):
    """Keyword-only gst_rate; returns (total, gst)."""
    gst = round(price * qty * gst_rate, 2)
    return round(price * qty + gst, 2), gst

def make_order():
    """Closure alternative: hidden per-customer list."""
    order = []
    def add(item):
        order.append(item)
        return list(order)
    return add

counter = 0
def bump_global():
    global counter
    counter += 1

def outer():
    n = 0
    def inner():
        nonlocal n
        n += 1
        return n
    inner(); inner()
    return n

if __name__ == "__main__":
    print("Buggy  :", add_item_buggy("tea"), add_item_buggy("coffee"))
    print("Shared default:", add_item_buggy.__defaults__)
    print("Fixed  :", add_item("tea"), add_item("coffee"))
    print("\nThree independent customers:")
    c1 = add_item("tea"); add_item("biscuit", c1)
    c2 = add_item("coffee")
    c3 = add_item("juice"); add_item("sandwich", c3); add_item("cake", c3)
    for i, c in enumerate((c1, c2, c3), 1):
        print(f"  Customer {i}: {c}")
    print("\nbill(250, 2):", bill(250, 2), " bill(100, gst_rate=0.05):", bill(100, gst_rate=0.05))
    a = make_order(); b = make_order()
    a("x"); print("closure a:", a("y"), " closure b:", b("z"))
    bump_global(); bump_global(); print("global counter:", counter, " nonlocal outer():", outer())
