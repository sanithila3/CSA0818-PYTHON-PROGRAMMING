"""Q7 - Diagnose, redesign, validate: SMS statement builder (+= vs join)."""
import time

def build_plus(parts):                  # ORIGINAL design
    text = ""
    for p in parts:
        text += p + ";"
    return text

def build_join(parts):                  # REDESIGN
    return ";".join(parts) + ";" if parts else ""

def build_stream(parts, fh):            # ALTERNATIVE when output goes to a file
    for p in parts:
        fh.write(p + ";")

def mean_time(fn, data, runs=3):
    ts = []
    for _ in range(runs):
        t0 = time.perf_counter(); fn(data); ts.append(time.perf_counter() - t0)
    return sum(ts) / len(ts)

if __name__ == "__main__":
    print("Objective: identical output, lower mean time at 200,000 fragments.\n")
    print(f"{'Fragments':>10} {'orig (s)':>10} {'join (s)':>10} {'speedup':>8}  correctness")
    for n in (1_000, 10_000, 200_000):
        data = [f"TXN{i:06d}:Rs{i % 997}" for i in range(n)]
        same = build_plus(data) == build_join(data)
        o, j = mean_time(build_plus, data), mean_time(build_join, data)
        print(f"{n:>10,} {o:>10.6f} {j:>10.6f} {o / j:>7.2f}x  {'PASS' if same else 'FAIL'}")
