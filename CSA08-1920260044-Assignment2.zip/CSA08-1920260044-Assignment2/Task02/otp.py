"""Q2 - Loops that count attempts (simulated input, so it is repeatable)."""

def verify_otp(entries, correct="4821", security_ok=False):
    """entries: iterable of typed strings. Blank entries do not count."""
    it = iter(entries)
    attempts, limit, extended = 0, 3, False
    while attempts < limit:
        try:
            entry = next(it).strip()
        except StopIteration:
            return "Input ended"
        if not entry:
            continue                      # blank: not counted
        attempts += 1
        if entry == correct:
            return f"Verified (attempt {attempts})"
        if attempts == 3 and not extended and security_ok:
            limit, extended = 5, True     # correct security answer: +2 attempts
    else:
        return "Account locked"           # runs only if loop was not broken


def verify_otp_recursive(entries, correct="4821", attempts=0, limit=3):
    """Recursive alternative: O(a) time, O(a) stack."""
    if attempts >= limit:
        return "Account locked"
    if not entries:
        return "Input ended"
    entry, rest = entries[0].strip(), entries[1:]
    if not entry:
        return verify_otp_recursive(rest, correct, attempts, limit)
    if entry == correct:
        return f"Verified (attempt {attempts + 1})"
    return verify_otp_recursive(rest, correct, attempts + 1, limit)


if __name__ == "__main__":
    tests = [
        ("correct first", ["4821"], False),
        ("blanks then correct", ["", " ", "4821"], False),
        ("3 wrong -> lock", ["1", "2", "3", "4821"], False),
        ("3 wrong + security ok, correct on 5th", ["1", "2", "3", "4", "4821"], True),
        ("5 wrong + security ok -> lock", ["1", "2", "3", "4", "5"], True),
    ]
    for name, data, sec in tests:
        print(f"{name:<42} -> {verify_otp(data, security_ok=sec)}")
    print("recursive:", verify_otp_recursive(["", "9", "4821"]))
