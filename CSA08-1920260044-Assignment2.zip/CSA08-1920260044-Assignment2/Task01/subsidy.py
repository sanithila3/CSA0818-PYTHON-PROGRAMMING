"""Q1 - Decisions with many boundaries."""

def decide_chain(units, ration_card, over_80):
    """if-elif-else chain: exactly one decision."""
    if units <= 100:
        return "Full subsidy"
    elif units <= 200:
        if ration_card:
            return "Partial subsidy"
        return "No subsidy"
    else:
        if over_80:
            return "Senior-member exception subsidy"
        return "No subsidy"


def decide_separate_ifs(units, ration_card, over_80):
    """Separate (overlapping) ifs: may return more than one label."""
    results = []
    if units <= 100:
        results.append("Full subsidy")
    if units <= 200 and ration_card:      # overlaps with the rule above
        results.append("Partial subsidy")
    if units > 200 and over_80:
        results.append("Senior-member exception subsidy")
    return results or ["No subsidy"]


def decide_match(units, ration_card, over_80):
    """match-case with guards (Python 3.10+)."""
    match (units, ration_card, over_80):
        case (u, _, _) if u <= 100:
            return "Full subsidy"
        case (u, True, _) if u <= 200:
            return "Partial subsidy"
        case (u, _, _) if u <= 200:
            return "No subsidy"
        case (_, _, True):
            return "Senior-member exception subsidy"
        case _:
            return "No subsidy"


if __name__ == "__main__":
    cases = [
        ("H1", 100, False, False), ("H2", 100, True, False),
        ("H3", 101, True, False),  ("H4", 101, False, False),
        ("H5", 200, True, False),  ("H6", 200, False, False),
        ("H7", 201, False, True),  ("H8", 201, True, False),
    ]
    print(f"{'ID':<4}{'Units':>6} {'Ration':<7}{'>80':<6}{'Chain':<34}{'Separate ifs'}")
    for hid, u, r, a in cases:
        chain = decide_chain(u, r, a)
        assert chain == decide_match(u, r, a)
        print(f"{hid:<4}{u:>6} {str(r):<7}{str(a):<6}{chain:<34}{decide_separate_ifs(u, r, a)}")
    print("\nOverlap demo (80 units, ration card):")
    print("  separate ifs:", decide_separate_ifs(80, True, False))
    print("  if-elif chain:", decide_chain(80, True, False))
