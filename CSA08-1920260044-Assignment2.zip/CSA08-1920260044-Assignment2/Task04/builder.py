"""Q4 - Building long text: += vs join() vs f-string + join."""
import time

def build_plus(parts):
    text = ""
    for p in parts:
        text += p + ";"
    return text

def build_join(parts):
    return ";".join(parts) + ";" if parts else ""

def build_fstring(parts):
    return "".join([f"{p};" for p in parts])

def mean_time(fn, data, runs=3):
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        fn(data)
        times.append(time.perf_counter() - t0)
    return sum(times) / len(times), times

if __name__ == "__main__":
    print(f"{'Items':>8} {'+= mean':>10} {'join mean':>10} {'ratio':>7} {'length':>10} equal")
    for n in (1_000, 10_000, 200_000):
        data = [f"TXN{i:06d}:Rs{i % 997}" for i in range(n)]
        a, b, c = build_plus(data), build_join(data), build_fstring(data)
        assert a == b == c, "outputs differ!"
        mp, tp = mean_time(build_plus, data)
        mj, tj = mean_time(build_join, data)
        print(f"{n:>8,} {mp:>10.6f} {mj:>10.6f} {mp / mj:>6.2f}x {len(a):>10,} {a == b}")
        print("   += runs:", [f"{t:.6f}" for t in tp], " join runs:", [f"{t:.6f}" for t in tj])
