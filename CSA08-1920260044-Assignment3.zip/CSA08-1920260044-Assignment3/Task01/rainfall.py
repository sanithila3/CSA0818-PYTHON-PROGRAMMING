"""Q1 - Lists and Slicing: Daily Rainfall Records"""
import random
import time
from collections import deque


def moving_average_naive(readings, window=7):
    if len(readings) < window:
        return []
    return [sum(readings[i:i + window]) / window
            for i in range(len(readings) - window + 1)]


def moving_average(readings, window=7):
    """Running-sum version: O(n) time, O(1) extra state."""
    if len(readings) < window:
        return []
    total = sum(readings[:window])
    result = [total / window]
    for i in range(window, len(readings)):
        total += readings[i] - readings[i - window]
        result.append(total / window)
    return result


def moving_average_deque(readings, window=7):
    """deque(maxlen=7): O(1) append/eviction."""
    win, total, out = deque(maxlen=window), 0, []
    for x in readings:
        if len(win) == window:
            total -= win[0]
        win.append(x)
        total += x
        if len(win) == window:
            out.append(total / window)
    return out


def make_readings(n, seed=42):
    rnd = random.Random(seed)
    # ~40% dry days (0 mm), otherwise 0.1-60 mm
    return [0 if rnd.random() < 0.4 else round(rnd.uniform(0.1, 60), 1)
            for _ in range(n)]


def main():
    readings = make_readings(365)
    weekly_totals = [sum(readings[i:i + 7])
                     for i in range(0, len(readings) - 6, 7)]
    wettest = max(range(len(weekly_totals)), key=weekly_totals.__getitem__)
    driest = min(range(len(weekly_totals)), key=weekly_totals.__getitem__)
    dry_days = [i + 1 for i, x in enumerate(readings) if x == 0]

    print("Readings:", len(readings))
    print("Weekly totals (first 5):", [round(w, 1) for w in weekly_totals[:5]])
    print(f"Wettest week: {wettest + 1} ({weekly_totals[wettest]:.1f} mm)")
    print(f"Driest week : {driest + 1} ({weekly_totals[driest]:.1f} mm)")
    print("Dry days count:", len(dry_days), "| first 10:", dry_days[:10])

    print("\nSlicing demo")
    print("readings[7:14] ->", readings[7:14])
    print("readings[-7:]  ->", readings[-7:])
    print("readings[::7][:5] ->", readings[::7][:5])

    ma = moving_average(readings)
    assert ma == moving_average_deque(readings) or all(
        abs(a - b) < 1e-9 for a, b in zip(ma, moving_average_deque(readings)))
    assert all(abs(a - b) < 1e-9 for a, b in zip(ma, moving_average_naive(readings)))
    print("\nMoving average count:", len(ma), "| first 3:", [round(x, 2) for x in ma[:3]])
    print("Edge case (<7 readings):", moving_average([1, 2, 3]))
    print("Edge case (empty):", moving_average([]))

    print("\n{:>8} {:>14} {:>18}".format("n", "Naive seconds", "Running-sum seconds"))
    for n in (365, 36500, 365000):
        data = make_readings(n)
        t = time.perf_counter(); moving_average_naive(data); t1 = time.perf_counter() - t
        t = time.perf_counter(); moving_average(data); t2 = time.perf_counter() - t
        print(f"{n:>8} {t1:>14.6f} {t2:>18.6f}")


if __name__ == "__main__":
    main()
