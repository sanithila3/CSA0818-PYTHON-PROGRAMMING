"""Q7 - Contact-Merging Program from First Principles
Stage 1 Requirements: merge contacts from several phones/SIMs; identity = normalised phone,
fallback = normalised name (flag for manual review).
Stage 2 Design: dictionary keyed by normalised phone -> {name, numbers set, emails set}.
"""
import json
import os
import time


def normalise_phone(phone):
    digits = "".join(ch for ch in (phone or "") if ch.isdigit())
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    return digits


def normalise_name(name):
    return "".join(ch for ch in (name or "").lower() if ch.isalpha())


def merge_contacts(contacts):
    merged = {}
    for c in contacts:
        key = normalise_phone(c.get("phone", ""))
        if not key:
            key = "name:" + normalise_name(c.get("name", ""))
        if key not in merged:
            merged[key] = {"name": c.get("name", ""), "numbers": set(), "emails": set()}
        if c.get("phone"):
            merged[key]["numbers"].add(c["phone"])
        if c.get("email"):
            merged[key]["emails"].add(c["email"].lower())
    return merged


def merge_pairwise(contacts):
    """O(n^2) alternative: compare each record with every merged record."""
    merged = []
    for c in contacts:
        p = normalise_phone(c.get("phone", ""))
        for m in merged:
            if p and p == m["key"]:
                if c.get("phone"): m["numbers"].add(c["phone"])
                if c.get("email"): m["emails"].add(c["email"].lower())
                break
        else:
            merged.append({"key": p, "name": c.get("name", ""),
                           "numbers": {c["phone"]} if c.get("phone") else set(),
                           "emails": {c["email"].lower()} if c.get("email") else set()})
    return merged


def synthetic(n):
    """n contacts, 2 records per person, different phone formats."""
    out = []
    for i in range(n // 2):
        num = f"9{i:09d}"[-10:]
        out.append({"name": f"Person {i}", "phone": f"+91 {num[:5]} {num[5:]}", "email": f"P{i}@x.com"})
        out.append({"name": f"Person {i}", "phone": num, "email": f"p{i}@x.com"})
    return out


def main():
    path = os.path.join(os.path.dirname(__file__), "contacts.json")
    with open(path, encoding="utf-8") as f:
        sample = json.load(f)
    result = merge_contacts(sample)
    print("Sample merge result:")
    for k, v in result.items():
        flag = "  <-- manual review (no phone)" if k.startswith("name:") else ""
        print(f"  {k}: {v['name']} | numbers={sorted(v['numbers'])} | emails={sorted(v['emails'])}{flag}")

    print("\nFormats merge? ", normalise_phone("+91 98400 12345") == normalise_phone("9840012345"))

    print("\n{:>8} {:>16} {:>12} {:>12}".format("Contacts", "Dict merge s", "Pairwise s", "Merged keys"))
    for n in (1000, 100000):
        data = synthetic(n)
        t = time.perf_counter(); m = merge_contacts(data); t1 = time.perf_counter() - t
        if n <= 1000:
            t = time.perf_counter(); merge_pairwise(data); t2 = f"{time.perf_counter() - t:.6f}"
        else:
            t2 = "Not run"
        print(f"{n:>8} {t1:>16.6f} {t2:>12} {len(m):>12}")


if __name__ == "__main__":
    main()
