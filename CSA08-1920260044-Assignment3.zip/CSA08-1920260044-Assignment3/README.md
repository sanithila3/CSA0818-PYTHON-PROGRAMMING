# CSA08-1920260044-Assignment3

**Name:** Nithila S A  
**Register Number:** 1920260044  
**Course Outcome:** CO3 - Python Data Structures  
**Python version:** 3.x (standard library only)

## Run commands
```
python Task01/rainfall.py
python Task02/grid_tuples.py
python Task03/complaints.py
python Task04/electives.py
python Task05/sensors.py
python Task06/timetable.py
python Task07/contact_merge.py
```

## Task summaries
| Task | Topic | Key idea |
|------|-------|----------|
| 01 | Lists & slicing - rainfall | Weekly slices, running-sum / deque moving average, O(n) |
| 02 | Tuples, mutability, copying | `[[0]*c]*r` aliasing bug, tuple keys, shallow vs deep copy |
| 03 | Dictionaries - complaints | dict.get counting vs Counter vs list.count |
| 04 | Sets - elective clashes | `&`, `^`, `|`, `-`; set vs list membership |
| 05 | List comprehension - sensors | loop vs comprehension vs map/filter |
| 06 | Nested data - timetable | dict of dicts, station index for fast queries |
| 07 | Contact merge | Normalise phone, dict grouping O(n) vs pairwise O(n^2) |

Timings vary by device; screenshots in each task folder are from my own runs.
