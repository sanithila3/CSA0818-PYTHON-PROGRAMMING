"""Q5 - List Comprehension: Cleaning Sensor Readings"""
import random
import time

readings = [4.5, 60, -70, 1.0, 9.5, 7.0, 50, -50, 3.2, 120]

# loop + append
clean_loop = []
for c in readings:
    if -50 <= c <= 50:
        clean_loop.append((c, c * 9 / 5 + 32))
# comprehension
clean_comp = [(c, c * 9 / 5 + 32) for c in readings if -50 <= c <= 50]
# map + filter
clean_mf = list(map(lambda c: (c, c * 9 / 5 + 32),
                    filter(lambda c: -50 <= c <= 50, readings)))
assert clean_loop == clean_comp == clean_mf

alarms = [i for i, c in enumerate(readings) if -50 <= c <= 50 and not 2 <= c <= 8]
print("Valid (C, F):", clean_comp)
print("Alarm minutes:", alarms)
print("Dict comp  :", {i: c for i, c in enumerate(readings) if -50 <= c <= 50})
print("Set comp   :", {c for c in readings if -50 <= c <= 50})
gen = (c * 9 / 5 + 32 for c in readings if -50 <= c <= 50)
print("Generator  :", gen, "->", list(gen))
print("All valid  :", [(c, c * 9 / 5 + 32) for c in [1, 2] if -50 <= c <= 50])
print("All invalid:", [(c, c * 9 / 5 + 32) for c in [100, -99] if -50 <= c <= 50])


def run_loop(data):
    out = []
    for c in data:
        if -50 <= c <= 50:
            out.append((c, c * 9 / 5 + 32))
    return out


def run_comp(data):
    return [(c, c * 9 / 5 + 32) for c in data if -50 <= c <= 50]


def run_mf(data):
    return list(map(lambda c: (c, c * 9 / 5 + 32), filter(lambda c: -50 <= c <= 50, data)))


print("\n{:>9} {:>10} {:>14} {:>12}".format("Readings", "Loop s", "Comprehension s", "filter+map s"))
for n in (10_000, 100_000, 1_000_000):
    rnd = random.Random(7)
    data = [rnd.uniform(-80, 80) for _ in range(n)]
    ts = []
    for fn in (run_loop, run_comp, run_mf):
        t = time.perf_counter(); fn(data); ts.append(time.perf_counter() - t)
    print(f"{n:>9} {ts[0]:>10.6f} {ts[1]:>14.6f} {ts[2]:>12.6f}")
