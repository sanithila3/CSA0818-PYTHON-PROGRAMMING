"""Q6 - Nested Data: A Railway Timetable"""
import random
import time
from collections import defaultdict

timetable = {
    "12601": {"name": "Coastal Express",
              "stops": [("Chennai Central", "06:00", "06:10"),
                        ("Tambaram", "06:40", "06:42"),
                        ("Villupuram", "08:00", "08:05")],
              "days": {"Mon", "Wed", "Fri"}},
    "12602": {"name": "Pallavan Express",
              "stops": [("Chennai Egmore", "05:30", "05:35"),
                        ("Tambaram", "06:05", "06:07"),
                        ("Trichy", "10:30", "10:35")],
              "days": {"Mon", "Tue", "Thu"}},
    "12603": {"name": "Vaigai Express",
              "stops": [("Chennai Egmore", "13:40", "13:45"),
                        ("Tambaram", "14:15", "14:17"),
                        ("Madurai", "21:30", "21:35")],
              "days": {"Sat", "Sun"}},
    "12604": {"name": "Pandian Express",
              "stops": [("Chennai Egmore", "21:15", "21:20"),
                        ("Tambaram", "21:50", "21:52"),
                        ("Madurai", "05:45", "05:50")],
              "days": {"Mon", "Wed", "Sat"}},
    "12605": {"name": "Cheran Express",
              "stops": [("Chennai Central", "22:00", "22:10"),
                        ("Katpadi", "00:05", "00:10"),
                        ("Coimbatore", "06:30", "06:40")],
              "days": {"Mon", "Fri"}},
}

print("Third stop departure of 12601:", timetable["12601"]["stops"][2][2])


def build_index(tt):
    idx = defaultdict(list)
    for no, d in tt.items():
        for st, arr, dep in d["stops"]:
            idx[st].append(no)
    return idx


def query_scan(tt, station, day):
    matches = [(no, d) for no, d in tt.items()
               if day in d["days"] and any(st == station for st, arr, dep in d["stops"])]
    matches.sort(key=lambda item: next(dep for st, arr, dep in item[1]["stops"] if st == station))
    return [no for no, _ in matches]


def query_index(tt, idx, station, day):
    cands = [no for no in idx.get(station, []) if day in tt[no]["days"]]
    cands.sort(key=lambda no: next(dep for st, arr, dep in tt[no]["stops"] if st == station))
    return cands


index = build_index(timetable)
print("Trains via Tambaram on Mon (scan) :", query_scan(timetable, "Tambaram", "Mon"))
print("Trains via Tambaram on Mon (index):", query_index(timetable, index, "Tambaram", "Mon"))
print("Unknown station:", query_index(timetable, index, "Atlantis", "Mon"))

# Timing
stations = [f"S{i}" for i in range(200)]
days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
print("\n{:>7} {:>18} {:>16}".format("Trains", "Full scan/query s", "Indexed query s"))
for n in (100, 1000, 10000):
    rnd = random.Random(3)
    tt = {str(i): {"name": f"T{i}",
                   "stops": [(s, "06:00", f"{rnd.randint(0, 23):02d}:{rnd.randint(0, 59):02d}")
                             for s in rnd.sample(stations, 6)],
                   "days": set(rnd.sample(days, 3))} for i in range(n)}
    idx = build_index(tt)
    t = time.perf_counter(); query_scan(tt, "S10", "Mon"); t1 = time.perf_counter() - t
    t = time.perf_counter(); query_index(tt, idx, "S10", "Mon"); t2 = time.perf_counter() - t
    print(f"{n:>7} {t1:>18.6f} {t2:>16.6f}")
