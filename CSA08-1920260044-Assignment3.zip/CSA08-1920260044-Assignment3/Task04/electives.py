"""Q4 - Sets: Elective Registration Clash Detection"""
import time

all_students = {f"1923110{i:02d}" for i in range(1, 11)}
ai_elective = {"192311001", "192311002", "192311004", "192311009"}
iot_elective = {"192311004", "192311007", "192311009", "192311010"}

both = ai_elective & iot_elective
exactly_one = ai_elective ^ iot_elective
neither = all_students - (ai_elective | iot_elective)
print("clash :", sorted(both))
print("exactly one:", sorted(exactly_one))
print("neither :", sorted(neither))

# Method equivalents
assert both == ai_elective.intersection(iot_elective)
assert exactly_one == ai_elective.symmetric_difference(iot_elective)
assert neither == all_students.difference(ai_elective.union(iot_elective))

# Edge cases
print("\nEmpty vs set:", set() & ai_elective, "| sym diff:", sorted(set() ^ ai_elective))
print("Identical electives sym diff:", ai_elective ^ ai_elective)
print("Duplicates removed:", set(["a", "a", "b"]))

# Membership timing
print("\n{:>10} {:>18} {:>18}".format("Registers", "List membership s", "Set membership s"))
for n in (10_000, 100_000, 1_000_000):
    lst = [str(i) for i in range(n)]
    st = set(lst)
    target = str(n - 1)
    t = time.perf_counter(); target in lst; t1 = time.perf_counter() - t
    t = time.perf_counter(); target in st; t2 = time.perf_counter() - t
    print(f"{n:>10} {t1:>18.9f} {t2:>18.9f}")
