"""Q2 - Tuples, Mutability and Copying"""
import copy
import sys

rows, cols = 3, 4
bad = [[0] * cols] * rows                       # same row object repeated
bad[0][1] = 7
good = [[0 for _ in range(cols)] for _ in range(rows)]   # TODO 1
good[0][1] = 7
print("bad :", bad)
print("good:", good)
print(bad[0] is bad[1], good[0] is good[1])

# Tuple as dictionary key vs list
zones = {(13.0418, 80.2341): "T. Nagar"}
print(zones[(13.0418, 80.2341)])
try:
    zones[[13.0418, 80.2341]] = "x"
except TypeError as e:
    print("TypeError:", e)

# Shallow vs deep copy
orig = [[1, 2], [3, 4]]
shallow = copy.copy(orig)
deep = copy.deepcopy(orig)
orig[0][0] = 99
print("\norig   :", orig)
print("shallow:", shallow, "(shares inner lists)")
print("deep   :", deep, "(independent)")

# Aliasing
def add_item(lst):
    lst.append("new")

a = [1, 2]
b = a
add_item(b)
print("\nAliasing: a =", a, "| a is b:", a is b)

# Tuple containing a list is still mutable inside
t = (1, [2, 3])
t[1].append(4)
print("Tuple with list inside after mutation:", t)
try:
    t[0] = 5
except TypeError as e:
    print("TypeError:", e)

# Container sizes
n = 1_000_000
print("\nContainer size for 1,000,000 references")
print("tuple:", sys.getsizeof(tuple(range(n))), "bytes")
print("list :", sys.getsizeof(list(range(n))), "bytes")

# Sparse grid alternative
sparse = {(0, 1): 7, (2, 3): 4}
print("\nSparse grid:", sparse, "| (0,1) ->", sparse.get((0, 1), 0), "| (1,1) ->", sparse.get((1, 1), 0))
