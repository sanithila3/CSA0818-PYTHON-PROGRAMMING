"""Q3 - Dictionaries: Farmer Helpline Complaint Analysis"""
import os
import random
import time
from collections import Counter

STOP = {"the", "of", "is", "to", "on", "and", "for", "not", "too", "a", "in", "need", "time", "high", "late"}


def frequencies(texts, stop):
    counts = {}
    for text in texts:
        for word in text.lower().split():
            word = word.strip(".,!?;:")
            if word and word not in stop:
                counts[word] = counts.get(word, 0) + 1
    return counts


def top(counts, k):
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:k]


def frequencies_counter(texts, stop):
    c = Counter()
    for text in texts:
        c.update(w for w in (x.strip(".,!?;:") for x in text.lower().split()) if w and w not in stop)
    return c


def frequencies_list_count(texts, stop):
    words = [w for w in (x.strip(".,!?;:") for t in texts for x in t.lower().split()) if w and w not in stop]
    return {w: words.count(w) for w in set(words)}


def main():
    path = os.path.join(os.path.dirname(__file__), "complaints.txt")
    with open(path, encoding="utf-8") as f:
        texts = [line.strip() for line in f if line.strip()]
    counts = frequencies(texts, STOP)
    print("Counts:", counts)
    print("Top 3 :", top(counts, 3))
    print("Empty text ->", frequencies([""], STOP))
    print("Case check ->", frequencies(["SEEDS seeds"], STOP))

    vocab = ["seeds", "price", "water", "subsidy", "loan", "pump", "rain", "crop", "market", "power"]
    print("\n{:>10} {:>12} {:>14} {:>14}".format("Complaints", "dict s", "Counter s", "list.count s"))
    for n in (1000, 10000, 100000):
        rnd = random.Random(1)
        data = [" ".join(rnd.choices(vocab, k=5)) for _ in range(n)]
        row = []
        for fn in (frequencies, frequencies_counter, frequencies_list_count):
            t = time.perf_counter(); fn(data, STOP); row.append(time.perf_counter() - t)
        print(f"{n:>10} {row[0]:>12.6f} {row[1]:>14.6f} {row[2]:>14.6f}")


if __name__ == "__main__":
    main()
