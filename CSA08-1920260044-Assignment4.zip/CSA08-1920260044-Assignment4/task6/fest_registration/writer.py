import csv
from pathlib import Path

FIELDS = ["register", "name", "department", "email", "events"]


def _write_students(path, students):
    with open(path, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        for student in students:
            row = dict(student)
            row["events"] = ";".join(student["events"])
            writer.writerow(row)


def write_outputs(master, event_map, errors, output_dir="output"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    _write_students(out / "master.csv", master)
    for event, students in event_map.items():
        safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in event)
        _write_students(out / f"{safe_name}.csv", students)
    with open(out / "summary.txt", "w", encoding="utf-8") as file:
        file.write(f"Unique registrations: {len(master)}\n")
        file.write(f"Events: {len(event_map)}\n")
        for event, students in sorted(event_map.items()):
            file.write(f"{event}: {len(students)} participants\n")
    with open(out / "error_log.txt", "w", encoding="utf-8") as file:
        for path, line_no, raw, reason in errors:
            file.write(f"{path} | line {line_no} | {reason} | {raw}\n")
