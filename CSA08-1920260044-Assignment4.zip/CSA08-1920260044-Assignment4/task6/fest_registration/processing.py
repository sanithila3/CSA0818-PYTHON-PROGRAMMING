from .validation import InvalidRegistration, parse_registration


def process_files(paths):
    seen, master, event_map, errors = set(), [], {}, []
    for path in paths:
        try:
            with open(path, "r", encoding="utf-8") as source:
                for line_no, line in enumerate(source, 1):
                    if not line.strip():
                        continue
                    try:
                        student = parse_registration(line)
                        reg = student["register"]
                        if reg in seen:
                            raise InvalidRegistration(f"duplicate register number '{reg}'")
                        seen.add(reg)
                        master.append(student)
                        for event in student["events"]:
                            event_map.setdefault(event, []).append(student)
                    except InvalidRegistration as exc:
                        errors.append((str(path), line_no, line.rstrip(), str(exc)))
        except (FileNotFoundError, PermissionError, UnicodeDecodeError, IsADirectoryError) as exc:
            errors.append((str(path), 0, "", f"{type(exc).__name__}: {exc}"))
    return master, event_map, errors
