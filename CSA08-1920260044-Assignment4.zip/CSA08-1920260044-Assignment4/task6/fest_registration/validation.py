class InvalidRegistration(Exception):
    pass


def validate_email(email):
    email = email.strip()
    if email.count("@") != 1 or " " in email:
        return False
    local, domain = email.split("@")
    return bool(local) and bool(domain) and "." in domain and not domain.startswith(".")


def parse_registration(line):
    fields = [field.strip() for field in line.rstrip("\r\n").split(",")]
    if len(fields) != 5:
        raise InvalidRegistration(f"expected 5 fields, found {len(fields)}")
    reg, name, department, email, event_text = fields
    if not reg or not name or not department:
        raise InvalidRegistration("register number, name and department are required")
    if not validate_email(email):
        raise InvalidRegistration(f"invalid email '{email}'")
    events = [event.strip() for event in event_text.split(";") if event.strip()]
    if not events:
        raise InvalidRegistration("at least one event is required")
    return {"register": reg, "name": name, "department": department,
            "email": email, "events": events}
