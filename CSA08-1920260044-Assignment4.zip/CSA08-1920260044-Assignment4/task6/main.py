from pathlib import Path
from fest_registration import process_files, write_outputs

if __name__ == "__main__":
    department_files = [Path("inputs") / f"department{i}.txt" for i in range(1, 6)]
    master, event_map, errors = process_files(department_files)
    write_outputs(master, event_map, errors)
    print("Completed:", len(master), "unique registrations;", len(errors), "issues logged.")
