def read_records(paths):
    records = {}
    errors = []
    for path in paths:
        try:
            with open(path, "r", encoding="utf-8") as file:
                for line_no, line in enumerate(file, 1):
                    if not line.strip():
                        continue
                    parts = [p.strip() for p in line.split(",")]
                    if len(parts) != 3 or parts[2] not in ("P", "A"):
                        errors.append((str(path), line_no, line.rstrip(), "invalid attendance row"))
                        continue
                    reg, date_text, status = parts
                    records.setdefault(reg, []).append((date_text, status))
        except (FileNotFoundError, PermissionError, UnicodeDecodeError) as exc:
            errors.append((str(path), 0, "", str(exc)))
    return records, errors
