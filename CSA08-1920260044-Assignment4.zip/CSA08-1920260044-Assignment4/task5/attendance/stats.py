from datetime import date, timedelta


def percentage(rows):
    if not rows:
        return 0.0
    present = sum(status == "P" for _, status in rows)
    return present * 100.0 / len(rows)


def absent_three_consecutive(rows):
    ordered = sorted(rows)
    streak = 0
    previous_date = None
    for date_text, status in ordered:
        current = date.fromisoformat(date_text)
        if status == "A":
            if previous_date is not None and current == previous_date + timedelta(days=1) and streak > 0:
                streak += 1
            else:
                streak = 1
            if streak >= 3:
                return True
        else:
            streak = 0
        previous_date = current
    return False
