from .stats import percentage, absent_three_consecutive


def write_reports(records, errors):
    with open("summary.csv", "w", encoding="utf-8") as out:
        out.write("register_number,percentage\n")
        for reg, rows in sorted(records.items()):
            out.write(f"{reg},{percentage(rows):.2f}\n")
    with open("three_day_absences.csv", "w", encoding="utf-8") as out:
        out.write("register_number\n")
        for reg, rows in sorted(records.items()):
            if absent_three_consecutive(rows):
                out.write(reg + "\n")
    with open("attendance_errors.csv", "w", encoding="utf-8") as out:
        out.write("file,line,raw,reason\n")
        for item in errors:
            out.write(",".join(str(x).replace(",", ";") for x in item) + "\n")
