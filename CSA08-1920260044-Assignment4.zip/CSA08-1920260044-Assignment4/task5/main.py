from pathlib import Path
from attendance import read_records, write_reports


def main():
    files = sorted(Path("daily_files").glob("*.txt"))
    records, errors = read_records(files)
    write_reports(records, errors)
    print(f"Processed {len(files)} files, {len(records)} students, {len(errors)} issues.")


if __name__ == "__main__":
    main()
