# CSA08 – Assignment 4 (CO4): Robust Data Processing
Student: Nithila S A | Register No: 1920260044 | Python 3.10+, standard library only.

| Folder | Task | Run |
|---|---|---|
| task1 | Mess report (repaired design) | `cd task1 && python mess_report.py` |
| task3 | Attendance parsing + custom exception | `cd task3 && python attendance_errors.py` |
| task4 | Library returns log: defects + repair | `cd task4 && python demo.py` |
| task5 | Attendance package (reader/stats/report) | `cd task5 && python main.py` |
| task6 | College fest registration desk | `cd task6 && python main.py` |

Tasks 2 is design/pseudocode only (see report). GitHub link: <add here>
