from decimal import Decimal, InvalidOperation


def create_mess_report(filename):
    total = Decimal("0.00")
    report_lines = []
    rejected_lines = []

    try:
        with open(filename, "r", encoding="utf-8") as file:
            for line_number, line in enumerate(file, start=1):
                if not line.strip():
                    continue
                parts = [part.strip() for part in line.split(",")]
                if len(parts) != 3:
                    rejected_lines.append((line_number, line.rstrip("\n"), "expected 3 fields"))
                    continue
                register_no, name, amount_text = parts
                try:
                    amount = Decimal(amount_text)
                except InvalidOperation:
                    rejected_lines.append((line_number, line.rstrip("\n"), "invalid amount"))
                    continue
                report_lines.append(f"{name} {amount:.2f}")
                total += amount
    except FileNotFoundError:
        print(f"Input file not found: {filename}")
        return [], Decimal("0.00"), []
    except PermissionError:
        print(f"Permission denied: {filename}")
        return [], Decimal("0.00"), []

    return report_lines, total, rejected_lines


if __name__ == "__main__":
    report, total, rejected = create_mess_report("mess_oct.txt")
    print("\n".join(report))
    print("Total", f"{total:.2f}")
    print("Rejected:", rejected)
