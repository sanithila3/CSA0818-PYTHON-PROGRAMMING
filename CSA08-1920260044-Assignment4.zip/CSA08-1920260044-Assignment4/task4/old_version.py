"""Defective version (for demonstration only)."""


def old_save_returns(books):
    log = open("returns_old.log", "w", encoding="utf-8")   # 'w' truncates every call
    for book in books:
        log.write(book)                                    # no newline written
    log.close()


def old_process(day_file):
    try:
        books = open(day_file, encoding="utf-8").read().split("\n")  # never closed
        old_save_returns(books)
    except FileNotFoundError:
        print("missing")
