from datetime import datetime


def save_returns(books, log_path="returns.log"):
    with open(log_path, "a", encoding="utf-8") as log:
        for book in books:
            if book.strip():
                log.write(book.rstrip("\r\n") + "\n")


def process(day_file):
    try:
        with open(day_file, "r", encoding="utf-8") as source:
            books = source.readlines()
        save_returns(books)
    except (FileNotFoundError, PermissionError, UnicodeDecodeError) as exc:
        with open("errors.log", "a", encoding="utf-8") as errors:
            errors.write(f"{datetime.now().isoformat()} | {day_file} | "
                         f"{type(exc).__name__}: {exc}\n")
        print(f"Could not process {day_file}: {exc}")


if __name__ == "__main__":
    for day in ("day1.txt", "day2.txt", "day3.txt"):
        process(day)
