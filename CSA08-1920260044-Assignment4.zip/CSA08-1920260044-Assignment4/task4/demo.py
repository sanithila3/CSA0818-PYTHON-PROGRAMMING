import old_version
import returns

for day in ("day1.txt", "day2.txt", "day3.txt"):
    old_version.old_process(day)
print("OLD LOG (only last day survives, IDs joined):")
print(open("returns_old.log", encoding="utf-8").read())

open("returns.log", "w").close()
for day in ("day1.txt", "day2.txt", "day3.txt", "day4_missing.txt"):
    returns.process(day)
print("REPAIRED LOG:")
print(open("returns.log", encoding="utf-8").read())
