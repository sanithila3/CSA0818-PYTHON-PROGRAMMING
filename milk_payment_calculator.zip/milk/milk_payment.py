"""Interactive / demo program. Usage: python milk_payment.py [--demo]"""
import sys
from decimal import Decimal, InvalidOperation
from milk_rate import (RATE_CARDS, rate_per_litre, payout, ten_day_total,
                       validate_delivery)


def read_decimal(prompt):
    while True:
        raw = input(prompt).strip()
        try:
            value = Decimal(raw)
            if not value.is_finite():
                raise InvalidOperation
            return value
        except (InvalidOperation, ValueError):
            print("Invalid number. Enter a value such as 8.50.")


def print_summary(s):
    print(f"Total litres  : {s['total_litres']:.2f} L")
    print(f"Base payment  : Rs {s['base_payment']:.2f}")
    print(f"Volume bonus  : Rs {s['bonus']:.2f}")
    print(f"Final payment : Rs {s['final_payment']:.2f}")


def demo():
    print("DEMONSTRATION - THREE DELIVERY ENTRIES")
    entries = [{"litres": "10", "fat": "3.50", "snf": "8.50"},
               {"litres": "8.50", "fat": "4.20", "snf": "8.70"},
               {"litres": "12", "fat": "3.10", "snf": "8.30"}]
    for i, e in enumerate(entries, 1):
        print(f"{i}. {e['litres']:>5} L | rate Rs {rate_per_litre(e['fat'], e['snf']):.2f}"
              f" | payment Rs {payout(**e):.2f}")
    print_summary(ten_day_total(entries))


def interactive():
    season = ""
    while season not in RATE_CARDS:
        season = input(f"Season {list(RATE_CARDS)}: ").strip().lower()
    n = int(read_decimal("Number of deliveries: "))
    entries = []
    for i in range(1, n + 1):
        print(f"--- Delivery {i} ---")
        while True:
            fid = input("Farmer ID: ").strip()
            shift = input("Shift (morning/evening): ").strip()
            litres = read_decimal("Litres: ")
            fat = read_decimal("Fat %: ")
            snf = read_decimal("SNF %: ")
            try:
                validate_delivery(fid, shift, litres, fat, snf)
                break
            except ValueError as err:
                print("Rejected:", err)
        entry = {"litres": litres, "fat": fat, "snf": snf}
        print(f"Rate Rs {rate_per_litre(fat, snf, season):.2f}/L, "
              f"payment Rs {payout(litres, fat, snf, season):.2f}")
        entries.append(entry)
    print_summary(ten_day_total(entries, season))


if __name__ == "__main__":
    demo() if "--demo" in sys.argv else interactive()
