from decimal import Decimal
print(type(10), type(10.0), type("F010"), type(True), type([10, 8.5]))
print(7 / 2, 7 // 2, 7 % 2, -7 // 2)
print(0.1 + 0.2 == 0.3)
print(Decimal("0.1") + Decimal("0.2") == Decimal("0.3"))
f = sum([33.40] * 1000) + 0.1 * 3
d = sum([Decimal("33.40")] * 1000) + Decimal("0.10") * 3
print("float  :", f)
print("Decimal:", d)
