# Milk Payment Calculator (CSA0818 - CO1)
Files: milk_rate.py (logic), milk_payment.py (CLI), test_milk_rate.py (15 tests),
types_demo.py, seasonal_demo.py.
Run: python milk_payment.py --demo | python test_milk_rate.py
