"""Reusable calculation logic for the Milk Payment Calculator."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

STANDARD_FAT = Decimal("3.5")
STANDARD_SNF = Decimal("8.5")
STEP_SIZE = Decimal("0.1")
MIN_FAT = Decimal("2.0")
MAX_FAT = Decimal("7.0")
BONUS_THRESHOLD = Decimal("500")
BONUS_PER_LITRE = Decimal("0.50")
CENT = Decimal("0.01")

RATE_CARDS = {
    "regular": {"base": Decimal("30.00"), "fat_step": Decimal("0.40"), "snf_step": Decimal("0.30")},
    "april-june": {"base": Decimal("32.00"), "fat_step": Decimal("0.45"), "snf_step": Decimal("0.30")},
}
SHIFTS = ("morning", "evening")


def as_decimal(value, name="Value"):
    """Convert to a finite Decimal (floats are routed through str)."""
    try:
        result = Decimal(str(value).strip())
    except (InvalidOperation, ValueError):
        raise ValueError(f"{name} must be a number.")
    if not result.is_finite():
        raise ValueError(f"{name} must be finite.")
    return result


def validate_delivery(farmer_id, shift, litres, fat, snf):
    if not str(farmer_id).strip():
        raise ValueError("Farmer ID is required.")
    if str(shift).strip().lower() not in SHIFTS:
        raise ValueError("Shift must be morning or evening.")
    if as_decimal(litres, "Litres") < 0:
        raise ValueError("Litres cannot be negative.")
    if not MIN_FAT <= as_decimal(fat, "Fat") <= MAX_FAT:
        raise ValueError("Fat must be between 2.0% and 7.0%.")
    if as_decimal(snf, "SNF") < 0:
        raise ValueError("SNF cannot be negative.")


def _steps(reading, standard):
    return ((reading - standard) / STEP_SIZE).quantize(Decimal("1"), rounding=ROUND_HALF_UP)


def rate_per_litre(fat, snf, season="regular"):
    fat, snf = as_decimal(fat, "Fat"), as_decimal(snf, "SNF")
    if not MIN_FAT <= fat <= MAX_FAT:
        raise ValueError("Fat must be between 2.0% and 7.0%.")
    if snf < 0:
        raise ValueError("SNF cannot be negative.")
    card = RATE_CARDS.get(str(season).lower())
    if card is None:
        raise ValueError(f"Unknown season: {season}")
    return (card["base"] + _steps(fat, STANDARD_FAT) * card["fat_step"]
            + _steps(snf, STANDARD_SNF) * card["snf_step"])


def payout(litres, fat, snf, season="regular"):
    litres = as_decimal(litres, "Litres")
    if litres < 0:
        raise ValueError("Litres cannot be negative.")
    rate = rate_per_litre(fat, snf, season)
    return (litres * rate).quantize(CENT, rounding=ROUND_HALF_UP)


def bonus_amount(total_litres):
    total_litres = as_decimal(total_litres, "Total litres")
    if total_litres > BONUS_THRESHOLD:
        return (total_litres * BONUS_PER_LITRE).quantize(CENT, rounding=ROUND_HALF_UP)
    return Decimal("0.00")


def ten_day_total(entries, season="regular"):
    """entries: iterable of dicts with litres, fat, snf. Returns a summary dict."""
    total_litres = Decimal("0")
    base_payment = Decimal("0.00")
    for e in entries:
        base_payment += payout(e["litres"], e["fat"], e["snf"], season)
        total_litres += as_decimal(e["litres"], "Litres")
    bonus = bonus_amount(total_litres)
    return {"total_litres": total_litres, "base_payment": base_payment,
            "bonus": bonus, "final_payment": base_payment + bonus}
