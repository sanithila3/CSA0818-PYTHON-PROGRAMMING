import unittest
from decimal import Decimal as D
from milk_rate import (rate_per_litre, payout, bonus_amount, ten_day_total,
                       validate_delivery)

SAMPLE = [{"litres": "200", "fat": "3.50", "snf": "8.50"},
          {"litres": "200", "fat": "4.25", "snf": "8.50"},
          {"litres": "150", "fat": "3.50", "snf": "8.50"}]


class MilkRateTests(unittest.TestCase):
    def test_standard_rate(self): self.assertEqual(rate_per_litre("3.5", "8.5"), D("30.00"))
    def test_quality_adjustment(self): self.assertEqual(payout("10", "4.20", "8.70"), D("334.00"))
    def test_lower_quality_adjustment(self): self.assertEqual(payout("12", "3.10", "8.30"), D("333.60"))
    def test_fat_boundary_min(self): self.assertEqual(rate_per_litre("2.0", "8.5"), D("24.00"))
    def test_fat_boundary_max(self): self.assertEqual(rate_per_litre("7.0", "8.5"), D("44.00"))
    def test_two_decimal_half_up_step(self): self.assertEqual(rate_per_litre("4.25", "8.50", "april-june"), D("35.60"))
    def test_seasonal_base_rate(self): self.assertEqual(rate_per_litre("3.5", "8.5", "april-june"), D("32.00"))
    def test_negative_litres_rejected(self):
        with self.assertRaises(ValueError): payout("-1", "3.5", "8.5")
    def test_negative_snf_rejected(self):
        with self.assertRaises(ValueError): rate_per_litre("3.5", "-1")
    def test_fat_outside_range_rejected(self):
        for fat in ("1.99", "7.01"):
            with self.assertRaises(ValueError): rate_per_litre(fat, "8.5")
    def test_invalid_shift_rejected(self):
        with self.assertRaises(ValueError): validate_delivery("F010", "night", "10", "3.5", "8.5")
    def test_unknown_season_rejected(self):
        with self.assertRaises(ValueError): rate_per_litre("3.5", "8.5", "winter")
    def test_bonus_threshold_is_strict(self):
        self.assertEqual(bonus_amount("500"), D("0.00"))
        self.assertEqual(bonus_amount("500.01"), D("250.01"))
    def test_ten_day_total_regular(self):
        self.assertEqual(ten_day_total(SAMPLE)["final_payment"], D("17415.00"))
    def test_ten_day_total_summer(self):
        self.assertEqual(ten_day_total(SAMPLE, "april-june")["final_payment"], D("18595.00"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
