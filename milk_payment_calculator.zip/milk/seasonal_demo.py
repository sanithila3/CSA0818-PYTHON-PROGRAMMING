from milk_rate import ten_day_total, rate_per_litre
entries = [{"litres": "200", "fat": "3.50", "snf": "8.50"},
           {"litres": "200", "fat": "4.25", "snf": "8.50"},
           {"litres": "150", "fat": "3.50", "snf": "8.50"}]
for season in ("regular", "april-june"):
    s = ten_day_total(entries, season)
    print(f"Season: {season}")
    print(f"Total litres: {s['total_litres']:.2f}")
    print(f"Payment before bonus: Rs {s['base_payment']:.2f}")
    print(f"Bonus: Rs {s['bonus']:.2f}")
    print(f"Final payment: Rs {s['final_payment']:.2f}\n")
print(f"April-June sample rate for fat 4.25%, SNF 8.50%: Rs {rate_per_litre('4.25','8.50','april-june'):.2f}")
